### CCAT - A better cat program
GNU cat is bloated. so i wrote my own cat in 15 lines.

## install
Its easy to install! Just run as root `make install`

## Usage
`ccat <file>`

Written by João Pedro de Moura Vasconcelos

2/22/22

Version 1.1.0
